﻿using System;
class lab9Alejandro_Chun_perez
{
    static void Main()
    
    {
        Console.WriteLine("Por favor, Ingrese el numero de la tabla que desea");
        int numeroTabla=Convert.ToInt32(Console.ReadLine());
        for (int i = 1; i <=10; i++)
        {
          int Opereacion = numeroTabla*i;
          Console.WriteLine(numeroTabla+"*"+ i+"="+Opereacion);
          
          
            
        }
    }
}