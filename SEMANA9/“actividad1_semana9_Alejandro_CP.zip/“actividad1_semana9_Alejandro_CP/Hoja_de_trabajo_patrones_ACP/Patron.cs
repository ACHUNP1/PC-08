﻿using System;
class Patron
{
  static void Main(string[] args)
  {
    Console.WriteLine("por favor escriba un numero que  no supere las 6 cifras");
    int numeroA=Convert.ToInt32(Console.ReadLine());
    if (numeroA>=1&& numeroA<=999999)
    {
         Console.WriteLine("Numero valido");
         if (numeroA > 1 && (numeroA == 2 || numeroA == 3 || (numeroA % 2 != 0 && numeroA % 3 != 0)))
         {
             Console.WriteLine("es primo");
         }
         else
         {
            Console.WriteLine("No es primo");
         }
    }

    else
    {
        Console.WriteLine("el numero es invalido "); 
    }

  }
}